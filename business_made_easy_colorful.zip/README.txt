
Business Made Easy
------------------
Files included:
- index.html, lessons.html, games.html, teacher.html, about.html
- style.css, script.js
- images/ (piggy.svg)
- README.txt (this file)

How to use:
1. Unzip the package.
2. Open index.html in a browser to run locally.
3. To host online, upload the folder to Netlify/Vercel/GitHub Pages.
4. The "Subscribe £1/month" button is a placeholder. Use Memberstack/Stripe/Gumroad to add payments.

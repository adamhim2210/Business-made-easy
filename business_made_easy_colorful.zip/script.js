
// Shared helpers
function el(id){return document.getElementById(id)}

// Navigation highlighting
document.addEventListener('DOMContentLoaded', ()=>{
  const path = location.pathname.split('/').pop() || 'index.html';
  const navs = document.querySelectorAll('a.navlink');
  navs.forEach(a=>{ if(a.getAttribute('href')===path) a.style.textDecoration='underline'; });
});

// Budgeting game logic
const defaultBudget = {
  income: 20,
  categories: [
    {name:'Food', allocated:6, spent:0},
    {name:'Transport', allocated:3, spent:0},
    {name:'Savings', allocated:5, spent:0},
    {name:'Fun', allocated:4, spent:0},
    {name:'Other', allocated:2, spent:0}
  ]
};

function loadBudget() {
  const raw = localStorage.getItem('bme_budget');
  if(raw) return JSON.parse(raw);
  localStorage.setItem('bme_budget', JSON.stringify(defaultBudget));
  return defaultBudget;
}

function saveBudget(b){localStorage.setItem('bme_budget', JSON.stringify(b))}

function renderBudget() {
  const b = loadBudget();
  el('incomeVal').textContent = '£' + b.income.toFixed(2);
  const catRoot = el('categories');
  catRoot.innerHTML = '';
  b.categories.forEach((c, idx)=>{
    const div = document.createElement('div');
    div.className = 'category';
    div.innerHTML = `<div><strong>${c.name}</strong><div class="small">Allocated: £<span id="alloc-${idx}">${c.allocated.toFixed(2)}</span> • Spent: £<span id="spent-${idx}">${c.spent.toFixed(2)}</span></div></div>
      <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
        <input class="input" id="spend-${idx}" type="number" placeholder="add spend" style="width:110px">
        <div style="display:flex;gap:6px"><button class="btn" onclick="addSpend(${idx})">Add</button></div>
      </div>`;
    catRoot.appendChild(div);
  });
  updateSummary();
}

function addSpend(idx) {
  const amount = Number(el('spend-'+idx).value) || 0;
  if(amount <=0) { alert('Enter a positive amount'); return; }
  const b = loadBudget();
  b.categories[idx].spent += amount;
  saveBudget(b);
  renderBudget();
  addLedgerEntry(b.categories[idx].name, amount);
}

function updateSummary() {
  const b = loadBudget();
  const totalAllocated = b.categories.reduce((s,c)=>s+c.allocated,0);
  const totalSpent = b.categories.reduce((s,c)=>s+c.spent,0);
  el('allocTotal').textContent = '£' + totalAllocated.toFixed(2);
  el('spentTotal').textContent = '£' + totalSpent.toFixed(2);
  el('remaining').textContent = '£' + (b.income - totalSpent).toFixed(2);
  // warnings
  if(totalSpent > b.income) {
    el('warn').textContent = '⚠️ You have spent more than your income! Try reducing spending.';
    el('warn').style.color = '#b00020';
  } else {
    el('warn').textContent = '';
  }
}

function addLedgerEntry(category, amount) {
  const entries = JSON.parse(localStorage.getItem('bme_ledger') || '[]');
  const now = new Date().toLocaleString();
  entries.unshift({time:now,category,amount});
  localStorage.setItem('bme_ledger', JSON.stringify(entries.slice(0,30)));
  renderLedger();
}

function renderLedger() {
  const entries = JSON.parse(localStorage.getItem('bme_ledger') || '[]');
  const root = el('ledger');
  if(!root) return;
  if(entries.length===0) { root.innerHTML='<div class="small muted">No transactions yet</div>'; return; }
  root.innerHTML = entries.map(e=>`<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px dashed #eef7ff"><div><strong>${e.category}</strong><div class="small">${e.time}</div></div><div>£${Number(e.amount).toFixed(2)}</div></div>`).join('');
}

// Reset budget
function resetBudget() {
  if(!confirm('Reset budget and ledger?')) return;
  localStorage.removeItem('bme_budget');
  localStorage.removeItem('bme_ledger');
  location.reload();
}

// Init on pages that have budget elements
document.addEventListener('DOMContentLoaded', ()=>{
  if(document.getElementById('categories')) {
    renderBudget();
    renderLedger();
  }
});
